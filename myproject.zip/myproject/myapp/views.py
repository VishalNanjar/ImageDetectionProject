from django.shortcuts import render, redirect 

def user_register(request):
    return render(request, 'UserRegistrationPage.html')

def user_login(request):
    return render(request, 'UserLoginPage.html')

def admin_login(request):
    return render(request, 'AdminLoginPage.html')

def home_page(request):
    return render(request, 'HomePage.html')

def home(request):
    return render(request, 'home.html')

def about_us(request):
    return render(request, 'about_us.html')

def more(request):
    return render(request, 'more.html')

def register(request):
    return render(request, 'UserRegistrationPage.html')

def login(request):
    return render(request, 'UserLoginPage.html')

def admin(request):
    return render(request, 'AdminLoginPage.html')

def regsuccess(request):
    return redirect(request, 'RegistrationSuccess.html')


    

