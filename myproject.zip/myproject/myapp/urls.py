from django.urls import path
from . import views


urlpatterns = [
    path('login/', views.user_login, name = 'user_login'),
    path('adminlogin/', views.admin_login, name = 'admin_login'),
    path('register/', views.user_register, name = 'user_register'),
    path('home/', views.home_page, name = 'home_page'),
    path('', views.home, name = 'home'),
    path('about/', views.about_us, name = 'about_us'),
    path('more/', views.more, name = 'more'),
    path('register/', views.register, name = 'register'),
    path('login/', views.login, name = 'login'),
    path('admin/', views.admin, name = 'admin'),
    path('regsuccess/', views.regsuccess, name='regsuccess'),
]

